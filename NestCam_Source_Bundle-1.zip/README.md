# NestCam Live Watch8 V1 — 手机 + Galaxy Watch 8

两个 APK 均从本仓库产生，无需 Cloud Shell、无需手动运行 Python。**这是首次集成的开发验证版：源码含真实 Nest SDM API 和 WebRTC 信令/解码代码，但尚未在用户的 backyard Nest Cam 和 Watch 8 真机上验证，不能保证第一次就播放成功。**

## 功能

- `mobile`：输入个人 Google OAuth Web Client ID 和 Client Secret（仅运行时输入，Android Keystore 本机加密）、Chrome 外部授权、从剪贴板粘贴回调 URL（含 `code=`）、兑换/自动刷新 Token、`devices.list`、Nest 手机 WebRTC 播放、自动延长 WebRTC 会话、Wear Data Layer 信令服务
- `wear`：Wear OS 设备列表、自动选择 backyard、手表本机 H.264 WebRTC 预览、连接状态、暂停、重连、通过配对手机请求直播和每三分钟延长会话
- `shared`：Google Nest WebRTC SDP 兼容处理、接收音视频轨道、SurfaceViewRenderer

## 一次上传 GitHub（在网页操作）

1. GitHub 新建空仓库，建议名称 `NestCam_Live_Watch8_V1`。
2. 解压本 ZIP，将**ZIP 内所有文件夹和隐藏的 `.github` 目录**上传到仓库根目录。GitHub 网页无法直接将 ZIP 作为工作流源码解压，需解压后上传里面的文件。
3. 点击 Actions → **Build NestCam Mobile + Watch8** → Run workflow（首次需允许 Actions），也可推送 main 自动触发。
4. 成功后下载两个 Actions Artifacts：`nestcam-mobile-debug-apk` 与 `nestcam-watch8-debug-apk`。
5. 安装两个 APK：`mobile-debug.apk` 手机安装；`wear-debug.apk` 安装到 Galaxy Watch 8。两个安装包使用相同的 applicationId 和相同签名（Google Wear Data Layer 的要求），分别安装在手机和手表上；它们不会覆盖 Google Home。

**构建环境**：AGP 8.9.2、Gradle 8.11.1、JDK 17、Android SDK 35（targetSdk 34）、Google Play services Wearable 20.0.1、Maven Central WebRTC 150.7871.08。

## 初次授权（不再使用 Cloud Shell）

1. 手机上打开 NestCam Live，点“配置 OAuth”。粘贴现有 Google Cloud 项目内 **Web 应用 OAuth Client ID** 和新创建的 Client Secret。不要将密钥写入任何 GitHub 文件。
2. 点“打开 Google Nest 授权”：用 Chrome 浏览器确认 backyard 的直播权限。回调目标为你此前配置的 `https://www.google.com`。
3. 完成后在 Chrome 地址栏复制**完整回调 URL**，回到手机 App，点“粘贴授权回调网址 / code”，确认粘贴；App 本机将 code 兑换令牌并调用 `devices.list`。
4. 在手机上确认摄像头并可选择播放，随后打开 Watch 8 App。手表与手机必须通过 Google Play Services Wearable Data Layer 能够通信，手表自身需要可用的网络连接。Watch 端不保存 Client Secret，不接收 Access Token。

**授权码一次性且短期有效**：如果 `invalid_grant`，回到第二步重新授权。Google OAuth Testing 状态下刷新令牌可能约 7 天失效，此时需要重新授权。**不要发送 code、Client Secret、Access Token 或 Refresh Token**。

## 当前范围和已知限制

- Google SDM WebRTC SDP 必须是 Unified Plan 且 m=audio / m=video / m=application 顺序，含 `recvonly` 的 Opus 音频、H264 视频和数据通道；由源码生成。
- **必须有配对的手机处理 OAuth/SDM API，手表不是完全独立云端客户端**。手表视频流在手表直接建立，不通过将手机画面截图转发。
- 数据层消息依赖 Google Play Services、配对与两设备联通性；Android 后台限制可能打断服务。这是开发版，尚无长期常驻前台服务或可靠断线重连保障。
- Nest Cam 电池版长期连接电源时才可延长直播；最初五分钟，App 会尝试延长。自动续期不代表 Google 保证无限播放。
- 人物/移动侦测震动提醒需要另外启用 Google Cloud Pub/Sub 与通知链路，**本 V1 不包含事件提醒**，以免误导。
- 用户过去配置的 OAuth Web 客户端使用 `https://www.google.com` 回调，V1 暂时需要复制 URL；正式产品应改为有自己可控域名或可信后端的 HTTPS 回调，以避免不便与潜在泄露。
- 该版本以手机和手表同时在线为设计前提。需在真实摄像头上测试 WebRTC 和 SDP 兼容。若编译失败，保存 GitHub Actions 日志中的第一条编译错误再修复；不要上传密钥。
- 由于开发环境没有 Android SDK/Gradle 构建服务，这里提供可编译项目与 CI 配置，**未在本地编译出 APK**。

## 重要安全说明

- Google Web OAuth 客户端的 `Client Secret` 属于**机密**，不得硬编码进公开 APK 或仓库；此个人版只让用户安装后自行输入，保存在 AndroidKeyStore 加密的本地存储中。
- Android 应用包含 secret 即使加密存储，也不等于强信任的服务器凭证保管；如果未来多人使用或共享设备，务必迁至服务端，并使用正式 HTTPS 回调及受控令牌服务。
- 关闭手机应用不会永久撤销授权；需要时可在 Google Partner Connections Manager 撤销授权。
- Google 官方文档：
  - https://developers.google.com/nest/device-access/api/camera-battery
  - https://developers.google.com/nest/device-access/traits/device/camera-live-stream
  - https://developers.google.com/nest/device-access/authorize
  - https://developer.android.com/training/wearables/data/overview
