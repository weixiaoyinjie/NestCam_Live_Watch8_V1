package com.nestcam.watch8.wear;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.wearable.MessageClient;
import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import com.nestcam.watch8.shared.RtcViewer;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Watch8 fullscreen player.
 * The PHONE still owns OAuth/SDM. All messages and their JSON fields are V1 compatible.
 * SurfaceViewRenderer + WebRTC EGL/peer/factory are released when leaving this screen.
 */
public class WatchActivity extends Activity implements MessageClient.OnMessageReceivedListener {
    private static final String REQ = "/nestcam/v1/request";
    private static final String RES = "/nestcam/v1/response";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicInteger counter = new AtomicInteger();
    private final List<Camera> cameras = new ArrayList<>();

    private FrameLayout root;
    private SurfaceViewRenderer surface;
    private RtcViewer rtc;
    private TextView nameView, statusView;
    private LinearLayout buttons;
    private Button playButton, cropButton;
    private Runnable keepAlive, retry, hideControls;
    private String nodeId = "";
    private int selected = -1;
    private boolean active = false, paused = true, controlsVisible = true, fill = true;

    private static final class Camera {
        final String name, id;
        Camera(String name, String id) { this.name = name; this.id = id; }
    }

    private int dp(float p) {
        return (int) (p * getResources().getDisplayMetrics().density + .5f);
    }

    private TextView text(String label, int size, int color) {
        TextView view = new TextView(this);
        view.setText(label);
        view.setTextColor(color);
        view.setTextSize(size);
        view.setGravity(Gravity.CENTER);
        view.setSingleLine(true);
        return view;
    }

    private Button button(String label, LinearLayout parent, Runnable action) {
        Button result = new Button(this);
        result.setText(label);
        result.setTextSize(11);
        result.setAllCaps(false);
        result.setMinWidth(0);
        result.setMinimumWidth(0);
        result.setPadding(0, 0, 0, 0);
        result.setTextColor(Color.WHITE);
        result.setBackgroundTintList(ColorStateList.valueOf(0xff23425c));
        parent.addView(result, new LinearLayout.LayoutParams(0, dp(39), 1));
        result.setOnClickListener(view -> {
            action.run();
            if (active) scheduleHide();
        });
        return result;
    }

    private void immersive() {
        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        getWindow().getDecorView().setSystemUiVisibility(flags);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        fill = getPreferences(MODE_PRIVATE).getBoolean("fill_screen", true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        root.setOnClickListener(view -> toggleControls());

        nameView = text("NestCam · backyard", 14, Color.WHITE);
        nameView.setPadding(dp(10), 0, dp(10), 0);
        nameView.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams nameParams = new FrameLayout.LayoutParams(dp(224), dp(27), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        nameParams.topMargin = dp(40); // keep controls away from the curved edge of a 44mm watch
        root.addView(nameView, nameParams);
        nameView.setOnClickListener(view -> cycleCamera());
        nameView.setOnLongClickListener(view -> { requestList(false); return true; });

        statusView = text("正在连接配对手机…", 11, Color.WHITE);
        statusView.setBackgroundColor(0xA5000000);
        statusView.setPadding(dp(5), dp(2), dp(5), dp(2));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(dp(224), dp(35), Gravity.CENTER);
        root.addView(statusView, statusParams);

        buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams actionsParams = new FrameLayout.LayoutParams(dp(232), dp(42), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        actionsParams.bottomMargin = dp(40);
        root.addView(buttons, actionsParams);

        playButton = button("■ 停止", buttons, () -> {
            if (active) stop(); else play();
        });
        button("↻ 重连", buttons, () -> { stop(); requestList(true); });
        cropButton = button("完整", buttons, this::toggleCrop);
        updateButtons();
        showControls();
    }

    private void initVideo() {
        if (rtc != null) return;
        surface = new SurfaceViewRenderer(this);
        root.addView(surface, 0, new FrameLayout.LayoutParams(-1, -1));
        surface.setOnClickListener(view -> toggleControls());
        rtc = new RtcViewer(this, surface, new RtcViewer.Listener() {
            @Override public void onOffer(String offer) {
                if (paused || !active || selected < 0 || selected >= cameras.size()) return;
                try {
                    send("START", new JSONObject()
                            .put("device", cameras.get(selected).id)
                            .put("offer", offer));
                } catch (Exception e) { status("直播请求失败"); }
            }
            @Override public void onStatus(String message) { status(message); }
        });
        setCrop();
    }

    private void setCrop() {
        if (surface != null) {
            surface.setScalingType(fill
                    ? RendererCommon.ScalingType.SCALE_ASPECT_FILL
                    : RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        }
        if (cropButton != null) cropButton.setText(fill ? "完整" : "铺满");
    }

    private void toggleCrop() {
        fill = !fill;
        getPreferences(MODE_PRIVATE).edit().putBoolean("fill_screen", fill).apply();
        setCrop();
    }

    private void updateButtons() {
        if (playButton != null) playButton.setText(active ? "■ 停止" : "▶ 播放");
    }

    private void showControls() {
        controlsVisible = true;
        nameView.setVisibility(View.VISIBLE);
        buttons.setVisibility(View.VISIBLE);
        statusView.setVisibility(View.VISIBLE);
        if (active) scheduleHide();
    }

    private void scheduleHide() {
        if (hideControls != null) ui.removeCallbacks(hideControls);
        hideControls = () -> {
            if (active && !paused) {
                nameView.setVisibility(View.GONE);
                buttons.setVisibility(View.GONE);
                statusView.setVisibility(View.GONE);
                controlsVisible = false;
            }
        };
        ui.postDelayed(hideControls, 5500);
    }

    private void toggleControls() {
        if (controlsVisible) {
            if (active) {
                if (hideControls != null) ui.removeCallbacks(hideControls);
                nameView.setVisibility(View.GONE);
                buttons.setVisibility(View.GONE);
                statusView.setVisibility(View.GONE);
                controlsVisible = false;
            }
        } else {
            showControls();
        }
    }

    private void status(String message) {
        ui.post(() -> {
            if (paused) return;
            statusView.setText(message);
            if (message.contains("视频轨道已连接") || message.contains("正在接收直播视频")) {
                scheduleHide();
            } else if (message.contains("失败") || message.contains("错误")
                    || message.contains("无法") || message.contains("未连接")) {
                showControls();
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        paused = false;
        immersive();
        initVideo();
        showControls();
        status("连接配对手机…");
        Wearable.getMessageClient(this).addListener(this)
                .addOnSuccessListener(unused -> { if (!paused) requestList(true); })
                .addOnFailureListener(e -> status("手表通信初始化失败"));
    }

    @Override protected void onPause() {
        paused = true;
        stop();
        Wearable.getMessageClient(this).removeListener(this);
        if (hideControls != null) ui.removeCallbacks(hideControls);
        // Fully release WebRTC, EGL and SurfaceView instead of keeping large native
        // decoder buffers resident when the watch app moves to the background.
        RtcViewer releasing = rtc;
        rtc = null;
        if (releasing != null) releasing.release();
        if (surface != null) {
            root.removeView(surface);
            surface = null;
        }
        super.onPause();
    }

    private void requestList(boolean autoPlay) {
        status("读取手机摄像头列表…");
        try { send("LIST", new JSONObject().put("auto", autoPlay)); }
        catch (Exception e) { status("无法连接手机"); }
    }

    private void send(String command, JSONObject params) {
        try {
            params.put("cmd", command);
            params.put("req", Integer.toString(counter.incrementAndGet()));
            byte[] body = params.toString().getBytes(StandardCharsets.UTF_8);
            Wearable.getNodeClient(this).getConnectedNodes()
                    .addOnSuccessListener(nodes -> {
                        if (nodes.isEmpty()) { status("未连接手机：检查蓝牙/Wi-Fi"); return; }
                        Node node = nodes.get(0);
                        nodeId = node.getId();
                        Wearable.getMessageClient(this).sendMessage(nodeId, REQ, body)
                                .addOnFailureListener(e -> status("发送失败：" + e.getClass().getSimpleName()));
                    })
                    .addOnFailureListener(e -> status("手表配对通信失败"));
        } catch (Exception e) { status("命令构造失败"); }
    }

    private void cycleCamera() {
        if (cameras.isEmpty()) { requestList(false); return; }
        selected = (selected + 1) % cameras.size();
        nameView.setText(cameras.get(selected).name + " ▾");
        stop();
        play();
    }

    private void play() {
        if (paused) return;
        if (selected < 0) { requestList(true); return; }
        if (active) return;
        initVideo();
        active = true;
        updateButtons();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showControls();
        if (rtc != null) rtc.start();
    }

    private void stop() {
        if (retry != null) ui.removeCallbacks(retry);
        if (keepAlive != null) ui.removeCallbacks(keepAlive);
        retry = null;
        keepAlive = null;
        boolean wasActive = active;
        active = false;
        updateButtons();
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (rtc != null) rtc.stop();
        if (wasActive) {
            try { send("STOP", new JSONObject()); }
            catch (Exception ignored) { }
        }
        if (!paused) showControls();
    }

    @Override public void onMessageReceived(MessageEvent event) {
        if (!RES.equals(event.getPath())) return;
        byte[] bytes = event.getData();
        if (bytes.length > 100000) return;
        String payload = new String(bytes, StandardCharsets.UTF_8);
        ui.post(() -> handle(payload));
    }

    private void handle(String raw) {
        if (paused) return;
        try {
            JSONObject response = new JSONObject(raw);
            String command = response.optString("cmd");
            if (!response.optBoolean("ok", false)) {
                status("Nest: " + response.optString("message", "连接失败"));
                if ("START".equals(command)) {
                    active = false;
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    updateButtons();
                    showControls();
                }
                if ("EXTEND".equals(command) && active) {
                    stop();
                    retry = () -> { if (!paused) play(); };
                    ui.postDelayed(retry, 3000);
                }
                return;
            }
            if ("LIST".equals(command)) {
                JSONArray list = response.optJSONArray("devices");
                if (list == null || list.length() == 0) {
                    status("没有摄像头：请在手机端检查授权");
                    return;
                }
                String previous = selected >= 0 && selected < cameras.size() ? cameras.get(selected).id : "";
                cameras.clear();
                int best = 0;
                for (int i = 0; i < list.length(); i++) {
                    JSONObject entry = list.getJSONObject(i);
                    Camera camera = new Camera(entry.getString("name"), entry.getString("id"));
                    if (camera.name.equalsIgnoreCase("backyard") || camera.id.equals(previous)) best = i;
                    cameras.add(camera);
                }
                selected = best;
                nameView.setText(cameras.get(selected).name + " ▾");
                status("发现 " + cameras.size() + " 台摄像头");
                if (!active) play();
            } else if ("START".equals(command)) {
                if (!active || rtc == null) return;
                rtc.setAnswer(response.getString("answer"));
                scheduleExtend();
            } else if ("EXTEND".equals(command)) {
                if (active) { status("直播续期成功"); scheduleExtend(); }
            } else if ("STOP".equals(command)) {
                status("已停止");
            }
        } catch (Exception e) {
            status("响应格式异常");
        }
    }

    private void scheduleExtend() {
        if (keepAlive != null) ui.removeCallbacks(keepAlive);
        if (!active || paused) return;
        keepAlive = () -> {
            if (paused || !active) return;
            status("正在延长直播…");
            try { send("EXTEND", new JSONObject()); }
            catch (Exception e) { status("续期请求失败"); }
        };
        ui.postDelayed(keepAlive, 180000);
    }

    @Override protected void onDestroy() {
        if (rtc != null) {
            rtc.release();
            rtc = null;
        }
        ui.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
