package com.nestcam.watch8.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import org.webrtc.RendererCommon;
import android.widget.*;
import com.nestcam.watch8.shared.RtcViewer;
import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.SurfaceViewRenderer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private NestApi api;
    private TextView state;
    private Spinner cameraSelector;
    private SurfaceViewRenderer surface;
    private RtcViewer rtc;
    private final ArrayList<JSONObject> cameras = new ArrayList<>();
    private String session = "", streamingDevice = "";
    private Runnable extension;
    private LinearLayout content;
    private FrameLayout screenRoot, fullScreenFrame;
    private LinearLayout videoHolder, fullScreenControls;
    private TextView fullScreenState;
    private ScrollView mainScroll;
    private boolean fullScreen = false, fillScreen = true;
    private volatile boolean screenRequestPending = false;
    private Runnable hideFullScreenControls;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,18,29));
        getWindow().setNavigationBarColor(Color.rgb(10,18,29));
        api = new NestApi(this);
        fillScreen = getPreferences(MODE_PRIVATE).getBoolean("video_fill", true);
        buildUi();
        // Existing OAuth tokens survive normal app restarts and same-signature APK upgrades.
        // No login or setup screen needed after first successful authorization.
        if (api.linked()) refresh(false);
    }
    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s, int sp, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        v.setPadding(0,dp(6),0,dp(6)); return v;
    }
    private Button button(String s, LinearLayout box, Runnable action) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(ColorStateList.valueOf(0xff243C5A));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(47));p.bottomMargin=dp(6);
        box.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private void title(String s) { content.addView(text(s,16,0xffD7E8FA)); }
    private void buildUi() {
        screenRoot = new FrameLayout(this);
        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);
        mainScroll.setBackgroundColor(0xff0C1521);
        content=new LinearLayout(this);content.setPadding(dp(17),dp(8),dp(17),dp(32));content.setOrientation(LinearLayout.VERTICAL);
        mainScroll.addView(content);
        screenRoot.addView(mainScroll,new FrameLayout.LayoutParams(-1,-1));
        setContentView(screenRoot);
        TextView heading=text("NestCam Live · 手机控制台",21,Color.WHITE);heading.setGravity(Gravity.CENTER);
        content.addView(heading);
        state=text(api.linked() ? "已保存 Nest 授权；点击下面的按钮即可看 backyard。" :
                   "首次使用请先配置 OAuth 并授权 backyard。",13,0xffB5CCE0);
        content.addView(state);
        button("▶ 一键查看 backyard · 全屏直播",content,this::quickWatch);
        title("① 授权与摄像头（仅首次）");
        button("配置 OAuth（首次一次）",content,this::configure);
        button("打开 Google Nest 授权",content,()->{
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(api.authorizationUrl()))); }
            catch(Exception ex){ status(ex.getMessage()); }
        });
        button("粘贴授权回调网址 / code",content,this::pasteAuth);
        button("刷新摄像头列表（自动检测）",content,()->refresh(false));
        cameraSelector=new Spinner(this);
        cameraSelector.setBackgroundTintList(ColorStateList.valueOf(0xffA4BDD6));
        content.addView(cameraSelector,new LinearLayout.LayoutParams(-1,dp(48)));
        cameraSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int index, long id) {
                if (index >= 0 && index < cameras.size())
                    getPreferences(MODE_PRIVATE).edit().putString("camera_id",cameras.get(index).optString("name")).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        title("② 手机实时监控");
        videoHolder = new LinearLayout(this);
        videoHolder.setOrientation(LinearLayout.VERTICAL);
        content.addView(videoHolder);
        surface=new SurfaceViewRenderer(this);
        LinearLayout.LayoutParams videoParams=new LinearLayout.LayoutParams(-1,dp(236));
        videoParams.bottomMargin=dp(10);
        videoHolder.addView(surface,videoParams);
        surface.setOnClickListener(v->{ if (fullScreen) toggleFullScreenControls(); else enterFullScreen(); });
        rtc=new RtcViewer(this,surface,new RtcViewer.Listener(){
            @Override public void onOffer(String offer){
                if(cameras.isEmpty() || cameraSelector.getSelectedItemPosition()<0){status("没有摄像头，请先刷新列表");return;}
                JSONObject d=cameras.get(cameraSelector.getSelectedItemPosition());
                String selected=d.optString("name");
                status("正在请求 Nest WebRTC 直播...");
                execute(()->api.start(selected,offer),answer->{
                    streamingDevice=selected;session=answer.optString("mediaSessionId");
                    screenRequestPending = false;
                    rtc.setAnswer(answer.optString("answerSdp"));
                    scheduleExtend(answer.optString("expiresAt"));
                });
            }
            @Override public void onStatus(String s){status(s);}
        });
        button("▶ 手机播放实时视频",content,this::quickWatch);
        button("⛶ 全屏观看当前画面",content,this::enterFullScreen);
        button("■ 停止播放",content,()->{stopPhone();exitFullScreen();});
        title("③ Galaxy Watch 8");
        content.addView(text("在已配对的 Watch 8 上安装手表 APK，打开后即可请求本机直播。手机负责令牌、SDM API 和直播续期；画面由手表自身解码。",13,0xffB5CCE0));
        button("检查手表连接",content,()->com.google.android.gms.wearable.Wearable.getNodeClient(this)
            .getConnectedNodes().addOnSuccessListener(nodes -> status("已连接 Wear OS 节点: " + nodes.size()))
            .addOnFailureListener(e->status("手表连接检查失败："+e.getClass().getSimpleName())));
        content.addView(text("安全：本 App 不预装密钥；你输入的 Client Secret、Token 会由 Android Keystore 在手机本地加密。授权使用外部 Chrome 浏览器，不使用 WebView。",12,0xff8BA5BE));
        button("清除本机全部授权信息",content,()->new AlertDialog.Builder(this)
            .setTitle("确认清除？").setMessage("删除本机保存的 Client ID、Secret 和访问令牌，不会删除 Google Cloud 项目。")
            .setNegativeButton("取消",null).setPositiveButton("清除",(d,w)->{stopPhone();api.clear();cameras.clear();state.setText("已清除本机授权信息");}).show());
    }
    private void status(String s){
        ui.post(()->{
            state.setText(s);
            if (fullScreenState != null) {
                fullScreenState.setText(s);
                fullScreenState.setVisibility(s.contains("视频轨道已连接") ? View.GONE : View.VISIBLE);
            }
        });
    }
    private interface Task { JSONObject run() throws Exception; }
    private interface Done { void run(JSONObject v); }
    private void execute(Task task,Done done) {
        io.execute(()->{try{JSONObject r=task.run();ui.post(()->done.run(r));}
          catch(Exception e){screenRequestPending=false;status("连接失败: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}});
    }
    private void field(String heading, boolean secret, String initial, java.util.function.Consumer<String> ok) {
        EditText edit=new EditText(this);edit.setTextColor(Color.BLACK);edit.setText(initial);
        edit.setSingleLine(!heading.contains("回调"));
        edit.setInputType(secret ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD :
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(22),0,dp(22),0);box.addView(edit,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this).setTitle(heading).setView(box).setNegativeButton("取消",null)
            .setPositiveButton("保存",(d,w)->ok.accept(edit.getText().toString().trim())).show();
    }
    private void configure() {
        field("OAuth Client ID",false,api.clientId(),id->{
            field("Client Secret（本机加密，不上传 GitHub）",true,"",secret->{
                try { api.configure(id,secret);status("OAuth 配置已安全保存在手机"); }
                catch(Exception e){status(e.getMessage());}
            });
        });
    }
    private void pasteAuth() {
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        String clip="";
        if(cb.hasPrimaryClip()) {
            ClipData data=cb.getPrimaryClip();
            if(data!=null&&data.getItemCount()>0) clip=data.getItemAt(0).coerceToText(this).toString();
        }
        field("粘贴含 code= 的回调 URL 或授权码",false,clip,value->{
            status("正在兑换 Google 授权令牌...");
            execute(()->{api.exchange(value);return new JSONObject().put("ok",true);},v->{status("授权成功，正在自动发现摄像头");refresh(false);});
        });
    }
    private void refresh(boolean playAfter){
        io.execute(()->{
            try {
                JSONArray found=api.devices();
                ArrayList<JSONObject> next=new ArrayList<>();ArrayList<String> names=new ArrayList<>();
                int preferred=0;
                String saved = getPreferences(MODE_PRIVATE).getString("camera_id", "");
                for(int i=0;i<found.length();i++){
                    JSONObject d=found.getJSONObject(i);
                    if(!NestApi.webrtc(d)) continue;
                    String n=NestApi.title(d);
                    if(n.equalsIgnoreCase("backyard") || d.optString("name").equals(saved)) preferred=next.size();
                    next.add(d);names.add(n+" · WebRTC");
                }
                int chosen=preferred;
                ui.post(()->{
                    cameras.clear();cameras.addAll(next);
                    ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
                    cameraSelector.setAdapter(adapter);
                    if(!names.isEmpty()) cameraSelector.setSelection(chosen);
                    status(next.isEmpty()?"暂无支持 WEB_RTC 的摄像头。请核对 Google Home 授权":"发现 "+next.size()+" 台摄像头；点击即可直播");
                    if (playAfter && !next.isEmpty()) startQuickVideo();
                });
            } catch(Exception e){status("获取设备失败："+e.getMessage());}
        });
    }
    private void scheduleExtend(String expiry) {
        if(extension!=null)ui.removeCallbacks(extension);
        if(session.isEmpty())return;
        long millis=220_000;
        try {millis=Instant.parse(expiry).toEpochMilli()-System.currentTimeMillis()-45_000;}catch(Exception ignored){}
        millis=Math.max(30_000,Math.min(millis,240_000));
        extension=()->{
            final String old=session,device=streamingDevice;
            if(old.isEmpty())return;
            execute(()->api.extend(device,old),json->{
                if(old.equals(session))scheduleExtend(json.optString("expiresAt"));
            });
        };
        ui.postDelayed(extension,millis);
    }
    private void stopPhone(){
        if(extension!=null)ui.removeCallbacks(extension);
        extension=null;
        screenRequestPending = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String prior=session,dev=streamingDevice;
        session="";streamingDevice="";
        if(rtc!=null)rtc.stop();
        if(!prior.isEmpty())io.execute(()->{try{api.stop(dev,prior);}catch(Exception ignored){}});
    }
    private void quickWatch() {
        if (!api.linked()) {
            status("首次使用需完成 Nest OAuth 授权，之后不必每次输入");
            return;
        }
        if (cameras.isEmpty()) {
            status("正在自动发现 backyard…");
            refresh(true);
        } else startQuickVideo();
    }
    private void startQuickVideo() {
        if (cameras.isEmpty()) {status("尚未找到摄像头");return;}
        if (screenRequestPending) return;
        stopPhone();
        screenRequestPending = true;
        enterFullScreen();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status("正在连接 backyard 实时画面…");
        rtc.start();
    }
    private void enterFullScreen() {
        if (fullScreen || surface == null) return;
        fullScreen = true;
        mainScroll.setVisibility(View.GONE);
        videoHolder.removeView(surface);
        fullScreenFrame = new FrameLayout(this);
        fullScreenFrame.setBackgroundColor(Color.BLACK);
        fullScreenFrame.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        screenRoot.addView(fullScreenFrame,new FrameLayout.LayoutParams(-1,-1));
        fullScreenState = text("正在连接 backyard…", 15, Color.WHITE);
        fullScreenState.setGravity(Gravity.CENTER);
        fullScreenState.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams stateParams = new FrameLayout.LayoutParams(-1, dp(48), Gravity.TOP);
        fullScreenFrame.addView(fullScreenState, stateParams);
        surface.setScalingType(fillScreen ? RendererCommon.ScalingType.SCALE_ASPECT_FILL : RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        fullScreenControls = new LinearLayout(this);
        fullScreenControls.setGravity(Gravity.CENTER);
        fullScreenControls.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams actions = new FrameLayout.LayoutParams(-1,dp(62),Gravity.BOTTOM);
        fullScreenFrame.addView(fullScreenControls,actions);
        fullButton("← 返回",()->exitFullScreen());
        fullButton(fillScreen?"完整画面":"铺满屏幕",()->toggleFill());
        fullButton("■ 停止",()->{stopPhone();exitFullScreen();});
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        scheduleControlHide();
    }
    private void fullButton(String label,Runnable action) {
        Button b=new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(ColorStateList.valueOf(0xff243C5A));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,dp(54),1);
        fullScreenControls.addView(b,p);
        b.setOnClickListener(v->action.run());
    }
    private void toggleFill(){
        fillScreen = !fillScreen;
        getPreferences(MODE_PRIVATE).edit().putBoolean("video_fill",fillScreen).apply();
        surface.setScalingType(fillScreen?RendererCommon.ScalingType.SCALE_ASPECT_FILL:
                                         RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        if(fullScreenControls != null && fullScreenControls.getChildCount()>1)
            ((Button)fullScreenControls.getChildAt(1)).setText(fillScreen?"完整画面":"铺满屏幕");
        scheduleControlHide();
    }
    private void toggleFullScreenControls(){
        if (!fullScreen || fullScreenControls == null) return;
        if (fullScreenControls.getVisibility()==View.VISIBLE) {
            fullScreenControls.setVisibility(View.GONE);
            if(hideFullScreenControls!=null)ui.removeCallbacks(hideFullScreenControls);
        } else {
            fullScreenControls.setVisibility(View.VISIBLE);
            scheduleControlHide();
        }
    }
    private void scheduleControlHide(){
        if (hideFullScreenControls!=null) ui.removeCallbacks(hideFullScreenControls);
        hideFullScreenControls=()->{if(fullScreen && fullScreenControls!=null)
            fullScreenControls.setVisibility(View.GONE);};
        ui.postDelayed(hideFullScreenControls,5000);
    }
    private void exitFullScreen() {
        if (!fullScreen) return;
        fullScreen = false;
        if (hideFullScreenControls!=null)ui.removeCallbacks(hideFullScreenControls);
        if (fullScreenFrame!=null) {
            fullScreenFrame.removeView(surface);
            screenRoot.removeView(fullScreenFrame);
        }
        fullScreenFrame=null;
        fullScreenControls=null;
        fullScreenState=null;
        videoHolder.addView(surface,new LinearLayout.LayoutParams(-1,dp(236)));
        surface.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        mainScroll.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }
    @Override public void onBackPressed() {
        if (fullScreen) exitFullScreen(); else super.onBackPressed();
    }
    @Override protected void onPause() {
        // Do not keep WebRTC decoder and network alive in the background.
        stopPhone();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        // Restore video when the user returns from another screen, without asking OAuth again.
        if (fullScreen && api != null && api.linked() && !cameras.isEmpty() && session.isEmpty()) {
            ui.postDelayed(this::startQuickVideo, 250);
        }
    }
    @Override protected void onDestroy(){stopPhone();exitFullScreen();if(rtc!=null)rtc.release();io.shutdown();super.onDestroy();}
}
