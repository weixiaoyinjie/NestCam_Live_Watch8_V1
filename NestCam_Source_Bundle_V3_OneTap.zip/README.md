# NestCam Live Watch8 V3 — 一次授权、点开就看、手机与手表全屏

此版基于既有 V1 双端源码迭代，**没有改变 Nest Device Access 项目 ID、OAuth redirect URI、应用包名、Wear OS 消息协议和 SDM API**。这是一份可供 GitHub Actions 编译的双端源码，不是已经在真机验证的视频 App。

## 日常使用

- **首次连接手机**：在手机 App 配置个人 Google OAuth Web Client ID + Client Secret（仅在本机 Android Keystore 中加密保存），通过官方 Google Nest Partner Connections 授权 `backyard`，粘贴授权回调的 code/网址。完成后 App 保存 refresh token。
- **此后手机**：启动后自动发现已有摄像头，点击首页 `▶ 一键查看 backyard · 全屏直播`；自动刷新 access token，向 Nest Cam 申请新的 WebRTC 会话。全屏轻触画面可显示/隐藏操作条；支持铺满与完整比例切换、停止、返回。
- **此后 Watch 8**：打开 Wear OS App 自动列出摄像头、默认选择 backyard 并开始请求 WebRTC 直播；画面由手表原生解码。轻触画面显示操作，默认铺满圆形屏幕；暂停/退出后释放解码资源。
- 手机用本地加密保存 OAuth 数据；手表通过配对手机的 Google Wear Data Layer 请求 SDM 信令，不保存 Client Secret。

## 不需每次登录，但不是永久授权

- Google OAuth access token 约 1 小时到期，App 可使用 refresh token 自动续期。
- **Google OAuth Consent Screen 如果保持 External / Testing，refresh token 可能在 7 天后失效**；届时必须在手机上重新授权。遇到 HTTP 400 `invalid_grant` 或其他明确授权失效时重新执行 Google Nest 授权。
- 每次打开直播都需要重新建立 WebRTC 流；此步骤由 App 自动执行。插电 Nest Cam WebRTC 流通常每 5 分钟需要根据到期时间延长，无法保证永不中断。
- 目前手表需要能够与手机正常通信（通常蓝牙/Wi-Fi/Google Play services），并且手机可访问 Google SDM API。

## GitHub 构建（手机+手表两个 APK）

1. 将 `NestCam_Source_Bundle_V3_OneTap.zip` 上传到 GitHub 仓库根目录**不要解压或改名**。
2. 将仓库 `.github/workflows/android.yml` 内容替换为随附的 `NestCam_V3_android.yml`。
3. 提交后进入 Actions，启动 `Build NestCam V3 Fullscreen OneTap`。
4. 下载 `nestcam-mobile-v3-debug-apk` 和 `nestcam-watch8-v3-debug-apk`，分别安装在 Android 手机和 Galaxy Watch 8。

**安装兼容性提醒**：Wear OS Data Layer 要求两端相同 `applicationId` 和签名。GitHub Actions 临时 Debug 签名每次运行可能变化；如果提示 `INSTALL_FAILED_UPDATE_INCOMPATIBLE`，新 APK 不能直接覆盖旧版。卸载手机旧版会清除它保存的 OAuth token，需要重新配置一次；以后想真正一直只授权一次，应使用稳定的私有签名密钥编译版本（不要把 keystore 或密码上传到公开 GitHub 仓库）。

**注意**：不要将 Client Secret、refresh token、授权码或下载的 OAuth JSON 上传到 GitHub 或发给他人。

## 当前限制

- 尚未完成本环境中的 Gradle/Android SDK APK 编译，也未验证手机/手表实机视频稳定性。需要以 Actions 编译日志和实际设备测试为准。
- 此版聚焦查看直播；Google Home 已有的移动侦测通知继续由官方应用承担，不新增重复推送。
- 第三方 App 无法保证实现 Google Home 所有原生专有功能。

参考：https://developers.google.com/nest/device-access/authorize ，https://developers.google.com/nest/device-access/traits/device/camera-live-stream ，https://developer.android.com/training/wearables/data/overview
